package com.intervueai.model;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;
import java.util.List;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
@Document("interviews")
public class Interview {
    @Id private String id;
    private String userId;
    private String jobRole;
    private String interviewType;
    private String difficulty;
    private int totalQuestions;
    private double score;
    private String status;
    private Instant startedAt;
    private Instant completedAt;
    private List<String> questionIds;
}