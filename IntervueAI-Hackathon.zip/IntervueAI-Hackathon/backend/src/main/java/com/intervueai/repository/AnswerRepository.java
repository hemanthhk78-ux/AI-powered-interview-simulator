package com.intervueai.repository;

import com.intervueai.model.Answer;
import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.List;

public interface AnswerRepository extends MongoRepository<Answer, String> {
    List<Answer> findByInterviewId(String interviewId);
}