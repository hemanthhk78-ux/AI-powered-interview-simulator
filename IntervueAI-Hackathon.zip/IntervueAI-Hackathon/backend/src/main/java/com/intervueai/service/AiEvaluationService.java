package com.intervueai.service;

import com.intervueai.model.Evaluation;
import com.intervueai.model.Improvement;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AiEvaluationService {

    @Value("${ai.provider:demo}")
    private String provider;

    /*
     * Hackathon-safe default: demo evaluation works without an external key.
     * For production, replace this method with a Gemini/OpenAI structured-output
     * call and keep the same Evaluation response contract.
     */
    public Evaluation evaluate(String question, String answer) {
        int words = answer.trim().isEmpty() ? 0 : answer.trim().split("\\s+").length;
        double score = words >= 45 ? 8.2 : words >= 25 ? 7.2 : 5.8;

        return Evaluation.builder()
                .score(score)
                .technicalAccuracy(Math.min(9.0, score + 0.3))
                .relevance(Math.min(9.5, score + 0.8))
                .communication(Math.max(5.5, score - 0.5))
                .completeness(Math.max(5.0, score - 0.4))
                .strengths(List.of(
                        "Answer is relevant to the question.",
                        "Uses appropriate technical terminology.",
                        "Shows understanding of the main concept."
                ))
                .weaknesses(List.of(
                        "No practical code or real-world example.",
                        "Technical explanation needs more depth.",
                        "Answer can be structured more clearly."
                ))
                .solutions(List.of(
                        Improvement.builder()
                                .title("Add a practical example")
                                .action("Explain the concept with a small Java example from a real project.")
                                .build(),
                        Improvement.builder()
                                .title("Improve technical depth")
                                .action("Revise the key internal mechanism and mention performance or trade-offs.")
                                .build(),
                        Improvement.builder()
                                .title("Use a 3-step answer structure")
                                .action("Start with definition, explain the mechanism, and finish with an example.")
                                .build()
                ))
                .feedback("Good foundation. Apply the improvement plan and retry the same concept.")
                .build();
    }
}