package com.intervueai.model;

import lombok.*;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class Improvement {
    private String title;
    private String action;
}