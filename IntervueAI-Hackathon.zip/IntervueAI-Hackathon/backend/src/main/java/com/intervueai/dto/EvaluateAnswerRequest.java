package com.intervueai.dto;

import jakarta.validation.constraints.NotBlank;

public record EvaluateAnswerRequest(
    @NotBlank String interviewId,
    @NotBlank String questionId,
    @NotBlank String questionText,
    @NotBlank String answerText
) {}