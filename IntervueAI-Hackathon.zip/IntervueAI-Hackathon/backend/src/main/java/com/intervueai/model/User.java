package com.intervueai.model;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
@Document("users")
public class User {
    @Id private String id;
    private String name;
    private String email;
    private String passwordHash;
    private String role;
    private Instant createdAt;
}