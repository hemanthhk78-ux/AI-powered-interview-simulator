package com.intervueai.model;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
@Document("answers")
public class Answer {
    @Id private String id;
    private String interviewId;
    private String questionId;
    private String questionText;
    private String answerText;
    private double score;
    private Evaluation evaluation;
}