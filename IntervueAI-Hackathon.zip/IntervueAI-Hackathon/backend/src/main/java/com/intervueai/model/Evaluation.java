package com.intervueai.model;

import lombok.*;
import java.util.List;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class Evaluation {
    private double score;
    private double technicalAccuracy;
    private double relevance;
    private double communication;
    private double completeness;
    private List<String> strengths;
    private List<String> weaknesses;
    private List<Improvement> solutions;
    private String feedback;
}