package com.intervueai.repository;

import com.intervueai.model.Interview;
import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.List;

public interface InterviewRepository extends MongoRepository<Interview, String> {
    List<Interview> findByUserIdOrderByStartedAtDesc(String userId);
}