package com.intervueai.dto;

import jakarta.validation.constraints.*;

public record CreateInterviewRequest(
    @NotBlank String userId,
    @NotBlank String jobRole,
    @NotBlank String interviewType,
    @NotBlank String difficulty,
    @Min(1) @Max(30) int totalQuestions
) {}