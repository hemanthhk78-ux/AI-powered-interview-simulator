package com.intervueai.service;

import com.intervueai.dto.CreateInterviewRequest;
import com.intervueai.model.Interview;
import com.intervueai.repository.InterviewRepository;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;

@Service
public class InterviewService {
    private final InterviewRepository repository;

    public InterviewService(InterviewRepository repository) {
        this.repository = repository;
    }

    public Interview create(CreateInterviewRequest request) {
        Interview interview = Interview.builder()
                .userId(request.userId())
                .jobRole(request.jobRole())
                .interviewType(request.interviewType())
                .difficulty(request.difficulty())
                .totalQuestions(request.totalQuestions())
                .score(0)
                .status("IN_PROGRESS")
                .startedAt(Instant.now())
                .build();
        return repository.save(interview);
    }

    public Interview get(String id) {
        return repository.findById(id).orElseThrow(
            () -> new IllegalArgumentException("Interview not found: " + id)
        );
    }

    public List<Interview> history(String userId) {
        return repository.findByUserIdOrderByStartedAtDesc(userId);
    }
}