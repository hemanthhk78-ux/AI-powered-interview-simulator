package com.intervueai.controller;

import com.intervueai.dto.CreateInterviewRequest;
import com.intervueai.dto.EvaluateAnswerRequest;
import com.intervueai.model.*;
import com.intervueai.repository.AnswerRepository;
import com.intervueai.service.AiEvaluationService;
import com.intervueai.service.InterviewService;
import jakarta.validation.Valid;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/interviews")
public class InterviewController {
    private final InterviewService interviews;
    private final AnswerRepository answers;
    private final AiEvaluationService ai;

    public InterviewController(InterviewService interviews, AnswerRepository answers, AiEvaluationService ai) {
        this.interviews = interviews; this.answers = answers; this.ai = ai;
    }

    @PostMapping
    public ResponseEntity<Interview> create(@Valid @RequestBody CreateInterviewRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(interviews.create(request));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Interview> get(@PathVariable String id) {
        return ResponseEntity.ok(interviews.get(id));
    }

    @PostMapping("/{id}/evaluate")
    public ResponseEntity<?> evaluate(@PathVariable String id,
                                      @Valid @RequestBody EvaluateAnswerRequest request) {
        Interview interview = interviews.get(id);
        if (!interview.getId().equals(request.interviewId())) {
            return ResponseEntity.badRequest().body(Map.of("message", "Interview ID mismatch"));
        }

        Evaluation evaluation = ai.evaluate(request.questionText(), request.answerText());
        Answer answer = Answer.builder()
                .interviewId(id)
                .questionId(request.questionId())
                .questionText(request.questionText())
                .answerText(request.answerText())
                .score(evaluation.getScore())
                .evaluation(evaluation)
                .build();

        answers.save(answer);
        return ResponseEntity.ok(evaluation);
    }
}