import React, { useState } from "react";
import { createRoot } from "react-dom/client";
import {
  ArrowRight, BrainCircuit, CheckCircle2, ChevronDown, Clock3, Code2,
  Flame, Home, LineChart, LockKeyhole, LogIn, Menu, Play, Search,
  ShieldCheck, Sparkles, Target, Trophy, UserRound, X, Zap, AlertTriangle,
  Lightbulb, History, Settings, BarChart3
} from "lucide-react";
import "./styles.css";

const demoEvaluation = {
  score: 8.2,
  technical: 8.5,
  relevance: 9.0,
  communication: 7.5,
  completeness: 7.8,
  strengths: [
    "Correctly identified the main OOP concept.",
    "Answer stayed relevant to the Java question.",
    "Good use of Java terminology."
  ],
  weaknesses: [
    "No practical code or real-world example.",
    "Method overriding was not explained deeply.",
    "The answer could be structured more clearly."
  ],
  solutions: [
    {
      title: "Add a practical example",
      action: "Explain polymorphism using a small Animal → Dog example and mention method overriding."
    },
    {
      title: "Improve technical depth",
      action: "Revise overloading vs overriding, compile-time vs runtime polymorphism, and dynamic method dispatch."
    },
    {
      title: "Use a 3-step answer structure",
      action: "Start with definition → explain mechanism → finish with a Java example."
    }
  ]
};

const history = [
  ["Java Developer", "Technical", "Oct 06, 2026", "8.2/10", "Completed"],
  ["Full Stack Developer", "Technical", "Oct 03, 2026", "7.6/10", "Completed"],
  ["Java Developer", "HR", "Sep 29, 2026", "8.8/10", "Completed"],
  ["Python Developer", "Technical", "Sep 25, 2026", "7.1/10", "Completed"]
];

function App() {
  const [page, setPage] = useState("landing");
  const [loggedIn, setLoggedIn] = useState(false);
  const [mobile, setMobile] = useState(false);

  const login = () => {
    setLoggedIn(true);
    setPage("dashboard");
  };

  if (page === "landing") return <Landing onLogin={() => setPage("login")} onStart={login} />;
  if (page === "login") return <Login onLogin={login} onBack={() => setPage("landing")} />;
  if (!loggedIn) return <Login onLogin={login} onBack={() => setPage("landing")} />;

  const content = {
    dashboard: <Dashboard go={setPage} />,
    interview: <Interview go={setPage} />,
    result: <Result go={setPage} />,
    analytics: <Analytics />,
    history: <HistoryPage />,
    profile: <Profile />,
    achievements: <Achievements />
  }[page] || <Dashboard go={setPage} />;

  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobile ? "mobile-open" : ""}`}>
        <div className="brand"><span className="brand-mark"><BrainCircuit size={19}/></span> Intervue<span>AI</span></div>
        <div className="user-mini">
          <div className="avatar">RK</div>
          <div><strong>Raman Kumar</strong><small>Java Developer</small></div>
        </div>
        <nav>
          <NavItem icon={<Home/>} text="Dashboard" active={page==="dashboard"} onClick={()=>{setPage("dashboard");setMobile(false)}}/>
          <NavItem icon={<Play/>} text="Start Interview" active={page==="interview"} onClick={()=>{setPage("interview");setMobile(false)}}/>
          <NavItem icon={<History/>} text="History" active={page==="history"} onClick={()=>{setPage("history");setMobile(false)}}/>
          <NavItem icon={<LineChart/>} text="Analytics" active={page==="analytics"} onClick={()=>{setPage("analytics");setMobile(false)}}/>
          <NavItem icon={<Target/>} text="Skill Analysis" active={page==="analytics"} onClick={()=>{setPage("analytics");setMobile(false)}}/>
          <NavItem icon={<Trophy/>} text="Achievements" active={page==="achievements"} onClick={()=>{setPage("achievements");setMobile(false)}}/>
          <NavItem icon={<UserRound/>} text="Profile" active={page==="profile"} onClick={()=>{setPage("profile");setMobile(false)}}/>
        </nav>
        <div className="sidebar-bottom">
          <NavItem icon={<Settings/>} text="Settings" onClick={()=>{}}/>
          <button className="logout" onClick={()=>{setLoggedIn(false);setPage("landing")}}>Log out</button>
        </div>
      </aside>
      <main className="main-area">
        <header className="topbar">
          <button className="icon-btn menu-btn" onClick={()=>setMobile(!mobile)}><Menu/></button>
          <div className="searchbox"><Search size={17}/><input placeholder="Search interviews, skills..." /></div>
          <div className="top-actions"><span className="status-dot"></span><span className="notification">3</span><div className="avatar small">RK</div></div>
        </header>
        {content}
      </main>
    </div>
  );
}

function NavItem({icon,text,active,onClick}) {
  return <button className={`nav-item ${active ? "active":""}`} onClick={onClick}>{icon}<span>{text}</span></button>;
}

function Landing({onLogin,onStart}) {
  return <div className="landing">
    <header className="landing-nav">
      <div className="brand"><span className="brand-mark"><BrainCircuit size={19}/></span> Intervue<span>AI</span></div>
      <div className="landing-links"><a href="#features">Features</a><a href="#how">How it works</a><a href="#roles">Roles</a></div>
      <div className="nav-cta"><button className="btn ghost" onClick={onLogin}>Login</button><button className="btn primary" onClick={onStart}>Get Started <ArrowRight size={16}/></button></div>
    </header>
    <section className="hero">
      <div className="hero-copy">
        <div className="pill"><Sparkles size={14}/> AI-powered interview preparation</div>
        <h1>Practice. <span>Perform.</span><br/>Get Hired.</h1>
        <p>Turn interview anxiety into interview confidence. Practice role-specific questions and get instant AI feedback on your technical depth, communication and weak areas.</p>
        <div className="hero-actions"><button className="btn primary large" onClick={onStart}>Start Free Interview <ArrowRight size={18}/></button><button className="btn dark-outline large"><Play size={16}/> Watch Demo</button></div>
        <div className="trust"><CheckCircle2 size={16}/> Personalized feedback <CheckCircle2 size={16}/> Skill-gap insights <CheckCircle2 size={16}/> Progress tracking</div>
      </div>
      <div className="hero-visual">
        <div className="orb"></div>
        <div className="floating-card card-a"><div className="mini-icon"><BrainCircuit/></div><div><b>AI Evaluation</b><small>Answer quality analyzed</small></div><strong>8.2</strong></div>
        <div className="laptop"><div className="screen"><div className="screen-top"><span></span><span></span><span></span></div><div className="fake-question">What is the difference between ArrayList and LinkedList?</div><div className="fake-lines"></div><div className="fake-btn"></div></div></div>
        <div className="floating-card card-b"><Flame size={19}/><div><b>7 Day Streak</b><small>Keep practicing!</small></div></div>
      </div>
    </section>
    <section id="features" className="section">
      <SectionTitle eyebrow="WHY INTERVUEAI" title="More than a mock interview." sub="Every answer becomes data you can use to improve."/>
      <div className="feature-grid">
        <Feature icon={<BrainCircuit/>} title="AI Evaluation" text="Score technical accuracy, relevance, communication and completeness."/>
        <Feature icon={<Target/>} title="Weakness → Solution" text="Don't just show what's wrong. Give a concrete action to fix it."/>
        <Feature icon={<BarChart3/>} title="Performance Analytics" text="Track your scores and skill growth across interviews."/>
        <Feature icon={<ShieldCheck/>} title="Personalized Practice" text="Use your role and profile to practice relevant questions."/>
      </div>
    </section>
    <section id="how" className="section alt"><SectionTitle eyebrow="HOW IT WORKS" title="Your interview coach in four steps."/>
      <div className="steps"><Step n="01" title="Choose your role" text="Select Java, Python, Full Stack, Data Analyst and more."/><Step n="02" title="Answer naturally" text="Take a realistic interview with timed questions."/><Step n="03" title="Get AI feedback" text="See your score, strengths and exact weaknesses."/><Step n="04" title="Improve & repeat" text="Follow the solution plan and track your progress." /></div>
    </section>
    <section id="roles" className="section"><SectionTitle eyebrow="SUPPORTED ROLES" title="Practice for the job you want."/>
      <div className="roles-grid">{["Java Developer","Python Developer","Full Stack Developer","Frontend Developer","Data Analyst","Software Engineer"].map((r,i)=><div className="role-card" key={r}><div className="role-icon">{["☕","🐍","⚡","⚛","📊","💻"][i]}</div><b>{r}</b><small>Technical + HR practice</small></div>)}</div>
    </section>
    <footer>© 2026 IntervueAI · Practice. Perform. Get Hired.</footer>
  </div>;
}

function Login({onLogin,onBack}) {
  const [email,setEmail]=useState("demo@intervueai.com");
  const [password,setPassword]=useState("demo123");
  const [error,setError]=useState("");
  const submit=(e)=>{e.preventDefault(); if(!email || !password){setError("Email and password are required.");return;} onLogin();};
  return <div className="auth-page"><div className="auth-brand"><button onClick={onBack} className="brand-back">←</button><div className="brand"><span className="brand-mark"><BrainCircuit size={19}/></span> Intervue<span>AI</span></div></div><div className="auth-card"><div className="auth-icon"><LockKeyhole/></div><div className="eyebrow">WELCOME BACK</div><h1>Login to your account</h1><p>Continue your interview preparation journey.</p><form onSubmit={submit}><label>Email address<input value={email} onChange={e=>setEmail(e.target.value)} type="email"/></label><label>Password<input value={password} onChange={e=>setPassword(e.target.value)} type="password"/></label>{error&&<div className="error"><AlertTriangle size={15}/>{error}</div>}<button className="btn primary full"><LogIn size={17}/> Login</button></form><div className="divider">or</div><button className="google-btn">Continue with Google</button><small className="demo-hint">Demo login is pre-filled. Click Login to enter the dashboard.</small></div></div>;
}

function Dashboard({go}) {
  return <div className="page"><PageHeader title="Good morning, Raman! 👋" sub="You're building stronger interview skills with every session."/>
    <div className="stat-grid"><Stat title="Overall Score" value="78%" change="+12%" icon={<Target/>}/><Stat title="Interviews" value="12" change="+3 this week" icon={<Play/>}/><Stat title="Questions" value="86" change="+10 this week" icon={<BrainCircuit/>}/><Stat title="Streak" value="7 days" change="Keep it up!" icon={<Flame/>}/></div>
    <div className="dashboard-grid">
      <section className="panel start-panel"><div className="panel-head"><div><div className="eyebrow">READY WHEN YOU ARE</div><h2>Start a new interview</h2></div><Sparkles className="purple"/></div><div className="form-grid"><Select label="Job Role" value="Java Developer"/><Select label="Interview Type" value="Technical Interview"/><Select label="Difficulty" value="Intermediate"/><Select label="Questions" value="10"/></div><button className="btn primary full" onClick={()=>go("interview")}>Start Interview <ArrowRight size={17}/></button></section>
      <section className="panel progress-panel"><div className="panel-head"><div><div className="eyebrow">YOUR PROGRESS</div><h2>Interview readiness</h2></div></div><div className="progress-ring"><div><b>78%</b><small>Ready</small></div></div><div className="progress-bars"><Bar label="Java" value={88}/><Bar label="Spring Boot" value={80}/><Bar label="SQL" value={72}/><Bar label="DSA" value={61}/></div></section>
    </div>
    <div className="dashboard-grid bottom"><section className="panel"><div className="panel-head"><div><div className="eyebrow">AI INSIGHT</div><h2>Your biggest opportunity</h2></div><Lightbulb className="gold"/></div><div className="insight"><div className="insight-icon">DSA</div><div><b>Strengthen DSA explanations</b><p>Your recent answers are technically correct, but you're losing points by skipping complexity and examples.</p><button className="text-btn" onClick={()=>go("analytics")}>View improvement plan <ArrowRight size={15}/></button></div></div></section><section className="panel"><div className="panel-head"><div><div className="eyebrow">QUICK ACCESS</div><h2>Continue your journey</h2></div></div><div className="quick-grid"><button onClick={()=>go("history")}><History/> Interview History</button><button onClick={()=>go("analytics")}><LineChart/> Check Analytics</button><button onClick={()=>go("profile")}><UserRound/> Edit Profile</button><button onClick={()=>go("achievements")}><Trophy/> Achievements</button></div></section></div>
  </div>;
}

function Interview({go}) {
  const [answer,setAnswer]=useState("");
  const [submitted,setSubmitted]=useState(false);
  return <div className="page interview-page"><PageHeader title="Java Developer Interview" sub="Technical Interview · Intermediate" action={<div className="timer"><Clock3/> 14:32</div>}/><div className="interview-layout"><section className="panel question-panel"><div className="question-top"><span className="tag">Technical</span><span>Question 3 of 10</span></div><div className="question-progress"><span style={{width:"30%"}}></span></div><h1>What is the difference between <span>ArrayList</span> and <span>LinkedList</span> in Java?</h1><p className="muted">Explain the internal data structure, performance and when you would choose each one.</p><textarea value={answer} onChange={e=>setAnswer(e.target.value)} placeholder="Type your answer here..."></textarea><div className="answer-footer"><span>{answer.length}/1500</span><button className="btn primary" onClick={()=>{if(answer.trim()) {setSubmitted(true);go("result")}}}>Submit Answer <ArrowRight size={17}/></button></div>{submitted&&<div className="success"><CheckCircle2/> Answer submitted successfully.</div>}</section><aside className="panel tips"><div className="eyebrow">AI INTERVIEW TIPS</div><h3>Answer like a professional</h3><Tip text="Start with a clear definition."/><Tip text="Compare concepts using a small table."/><Tip text="Mention time complexity when relevant."/><Tip text="Give one practical use case."/><div className="mini-progress"><div><span>Progress</span><b>30%</b></div><div className="line"><span style={{width:"30%"}}></span></div><small>3 of 10 questions</small></div></aside></div></div>;
}

function Result({go}) {
  return <div className="page"><PageHeader title="AI Evaluation" sub="Your answer has been analyzed." action={<span className="completed"><CheckCircle2/> Completed</span>}/><div className="score-hero panel"><div className="score-ring"><div><b>8.2</b><small>/10</small></div></div><div><div className="eyebrow">OVERALL SCORE</div><h1>Good performance</h1><p>You have a solid understanding. Add practical examples and a clearer structure to make your answer stronger.</p></div></div><div className="evaluation-grid"><section className="panel"><div className="panel-head"><h2>Score breakdown</h2></div><Bar label="Technical accuracy" value={85}/><Bar label="Relevance" value={90}/><Bar label="Communication" value={75}/><Bar label="Completeness" value={78}/></section><section className="panel"><div className="panel-head"><h2>Strengths</h2><CheckCircle2 className="green"/></div>{demoEvaluation.strengths.map(x=><div className="bullet good" key={x}><CheckCircle2/>{x}</div>)}</section><section className="panel"><div className="panel-head"><h2>Weaknesses</h2><AlertTriangle className="red"/></div>{demoEvaluation.weaknesses.map(x=><div className="bullet bad" key={x}><AlertTriangle/>{x}</div>)}</section></div><section className="panel solutions"><div className="panel-head"><div><div className="eyebrow">ACTION PLAN</div><h2>Turn weaknesses into solutions</h2><p className="muted">Don't just see a low score. Know exactly what to do next.</p></div><Lightbulb className="gold"/></div><div className="solution-grid">{demoEvaluation.solutions.map((s,i)=><div className="solution-card" key={s.title}><div className="solution-number">0{i+1}</div><div><h3>{s.title}</h3><p>{s.action}</p><button className="text-btn">Add to practice plan <ArrowRight size={15}/></button></div></div>)}</div></section><div className="result-actions"><button className="btn dark-outline" onClick={()=>go("analytics")}>View Analytics</button><button className="btn primary" onClick={()=>go("interview")}>Next Question <ArrowRight size={17}/></button></div></div>;
}

function Analytics() {
  return <div className="page"><PageHeader title="Performance Analytics" sub="Track progress and identify what to improve." action={<select className="period"><option>Last 30 days</option><option>Last 7 days</option><option>All time</option></select>}/><div className="analytics-top"><div className="panel big-chart"><div className="panel-head"><div><div className="eyebrow">INTERVIEW PROGRESS</div><h2>Score growth</h2></div><span className="positive">+17% ↗</span></div><div className="chart"><div className="ylabels"><span>100</span><span>75</span><span>50</span><span>25</span><span>0</span></div><div className="chart-area"><div className="gridlines"></div><svg viewBox="0 0 700 230" preserveAspectRatio="none"><polyline points="10,170 160,145 310,120 460,80 610,52 690,35" fill="none" stroke="currentColor" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round"/></svg><div className="chart-points">{[["1","61%"],["2","66%"],["3","71%"],["4","78%"],["5","82%"],["6","86%"]].map((p,i)=><div style={{left:`${2+i*18.5}%`}} key={p[0]}><i></i><small>{p[0]}</small></div>)}</div></div></div></div><div className="panel"><div className="eyebrow">READINESS</div><h2>86%</h2><p className="muted">You're interview-ready for Junior Java Developer roles.</p><div className="ready-bar"><span style={{width:"86%"}}></span></div><b className="positive">+8% this month</b></div></div><div className="analytics-grid"><section className="panel"><div className="panel-head"><div><div className="eyebrow">SKILL PERFORMANCE</div><h2>Your skills</h2></div></div><Bar label="Java" value={88}/><Bar label="Spring Boot" value={80}/><Bar label="SQL" value={72}/><Bar label="Communication" value={75}/><Bar label="DSA" value={61}/></section><section className="panel"><div className="panel-head"><div><div className="eyebrow">AI RECOMMENDATION</div><h2>Focus for next 7 days</h2></div></div><div className="recommendation"><span>01</span><div><b>DSA concepts</b><p>Practice arrays, linked lists, stacks and explain complexity.</p></div></div><div className="recommendation"><span>02</span><div><b>SQL queries</b><p>Revise joins, grouping and subqueries with coding exercises.</p></div></div><div className="recommendation"><span>03</span><div><b>Answer structure</b><p>Use definition → mechanism → example for technical answers.</p></div></div></section></div></div>;
}

function HistoryPage(){return <div className="page"><PageHeader title="Interview History" sub="Review your previous interviews and improvement." action={<button className="btn ghost">Filter <ChevronDown size={15}/></button>}/><section className="panel table-panel"><table><thead><tr><th>Job Role</th><th>Type</th><th>Date</th><th>Score</th><th>Status</th></tr></thead><tbody>{history.map((r,i)=><tr key={i}>{r.map((c,j)=><td key={j}>{j===3?<strong>{c}</strong>:j===4?<span className="status-complete">{c}</span>:c}</td>)}</tr>)}</tbody></table></section></div>}

function Profile(){return <div className="page"><PageHeader title="My Profile" sub="Manage your personal information and interview preferences." action={<button className="btn primary">Edit Profile</button>}/><div className="profile-grid"><section className="panel profile-card"><div className="profile-head"><div className="avatar large">RK</div><div><h2>Raman Kumar</h2><p>Java Developer · Student</p><span className="verified"><CheckCircle2/> Profile verified</span></div></div><div className="profile-fields"><Field label="Email" value="raman@example.com"/><Field label="Education" value="B.Tech Computer Science"/><Field label="Experience" value="Fresher"/><Field label="Target role" value="Java Full Stack Developer"/></div></section><section className="panel"><div className="eyebrow">SKILLS</div><h2>Your technical profile</h2><div className="chips">{["Java","Spring Boot","MongoDB","SQL","DSA","React","REST API","Git"].map(x=><span key={x}>{x}</span>)}</div><div className="resume-box"><Code2/><div><b>Resume.pdf</b><small>Uploaded · Ready for personalized questions</small></div><button className="btn ghost">View</button></div></section></div></div>}

function Achievements(){return <div className="page"><PageHeader title="Achievements" sub="Milestones that keep your preparation moving."/><div className="achievement-grid">{[["🏆","First Interview","Complete your first interview","Unlocked"],["🔥","7 Day Streak","Practice for 7 consecutive days","Unlocked"],["⭐","Perfect Answer","Score 10/10","Locked"],["☕","Java Master","Score above 85% in 5 Java interviews","Unlocked"],["🚀","Interview Ready","Complete 20 interviews","Locked"],["🎯","Weakness Crusher","Improve a weak skill by 20%","Unlocked"]].map(a=><div className={`panel achievement ${a[3]==="Locked"?"locked":""}`} key={a[1]}><div className="badge-icon">{a[0]}</div><h3>{a[1]}</h3><p>{a[2]}</p><span>{a[3]}</span></div>)}</div></div>}

function PageHeader({title,sub,action}){return <div className="page-header"><div><h1>{title}</h1><p>{sub}</p></div>{action}</div>}
function SectionTitle({eyebrow,title,sub}){return <div className="section-title"><div className="eyebrow">{eyebrow}</div><h2>{title}</h2>{sub&&<p>{sub}</p>}</div>}
function Feature({icon,title,text}){return <div className="feature-card"><div className="feature-icon">{icon}</div><h3>{title}</h3><p>{text}</p></div>}
function Step({n,title,text}){return <div className="step"><span>{n}</span><h3>{title}</h3><p>{text}</p></div>}
function Stat({title,value,change,icon}){return <div className="panel stat"><div className="stat-icon">{icon}</div><small>{title}</small><h2>{value}</h2><span>{change}</span></div>}
function Select({label,value}){return <label className="select-label"><span>{label}</span><div>{value}<ChevronDown size={15}/></div></label>}
function Bar({label,value}){return <div className="bar-wrap"><div><span>{label}</span><b>{value}%</b></div><div className="bar"><span style={{width:`${value}%`}}></span></div></div>}
function Tip({text}){return <div className="tip"><CheckCircle2 size={15}/>{text}</div>}
function Field({label,value}){return <div className="field"><small>{label}</small><b>{value}</b></div>}

createRoot(document.getElementById("root")).render(<App />);
