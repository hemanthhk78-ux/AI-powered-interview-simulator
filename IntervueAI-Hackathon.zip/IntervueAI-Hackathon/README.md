# IntervueAI — AI-Based Mock Interview Simulator

Hackathon-ready Java Full Stack + AI prototype.

## What this project solves

Students often practice interviews without knowing exactly what is wrong with their answers. IntervueAI converts each answer into an actionable improvement plan.

### Weakness → Solution system

| Weakness detected | Product solution |
|---|---|
| Missing technical depth | AI gives the missing concepts and a better-answer outline |
| No practical examples | AI recommends a real-world/project example |
| Poor communication | AI provides concise speaking tips |
| Incomplete answer | AI lists missing points and follow-up concepts |
| Weak DSA/SQL/OOP knowledge | Skill-gap analysis creates targeted practice areas |
| Repeating the same mistakes | Interview history tracks recurring weaknesses |
| No measurable progress | Analytics compares interview scores over time |
| Generic preparation | Resume/profile data can be used for personalized questions |

## Main features

- Professional landing page
- Login/Register flow
- Student dashboard
- Job-role and difficulty selection
- Mock interview workspace
- AI answer evaluation
- Score, strengths, weaknesses and improvement suggestions
- Weakness-to-solution cards
- Skill-gap analytics
- Interview history
- Achievements and streaks
- Profile/resume area
- Responsive design
- Loading, validation, success and error states
- Spring Boot REST API
- MongoDB with Spring Data MongoDB
- JWT-ready authentication structure
- Configurable Gemini/OpenAI AI provider
- Git/GitHub-ready structure

## Architecture

React → Spring Boot REST API → Service Layer → MongoDB  
                                        ↘ AI Provider

## Run frontend

```bash
cd frontend
npm install
npm run dev
```

Open the Vite URL shown in the terminal.

The frontend works in demo mode without a backend, so the complete UI can be presented during a hackathon.

## Run backend

Requirements:
- Java 17+
- Maven 3.9+
- MongoDB

```bash
cd backend
mvn spring-boot:run
```

Backend runs on `http://localhost:8080`.

Set environment variables when using real AI:

```text
MONGODB_URI=mongodb://localhost:27017/intervueai
AI_PROVIDER=gemini
AI_API_KEY=your_key_here
```

Never commit API keys.

## REST endpoints

```text
POST /api/auth/register
POST /api/auth/login
GET  /api/job-roles
POST /api/interviews
GET  /api/interviews/{id}
POST /api/interviews/{id}/evaluate
GET  /api/users/{userId}/interviews
GET  /api/users/{userId}/analytics
```

## Suggested Git commits

```text
feat: create professional landing page
feat: add authentication screens
feat: create student dashboard
feat: add mock interview workspace
feat: integrate MongoDB persistence
feat: add AI answer evaluation
feat: add weakness to solution engine
feat: add performance analytics
feat: add interview history
docs: add architecture and setup guide
```

## Hackathon demo story

1. Open landing page.
2. Login as a student.
3. Dashboard shows score, interviews, streak and skill gaps.
4. Start Java Developer interview.
5. Answer a technical question.
6. Submit answer.
7. Show AI score.
8. Show strengths.
9. Show weaknesses.
10. Show exact solutions for each weakness.
11. Open analytics to prove progress tracking.
12. Open history to show previous interviews.

## Important note

The frontend demo uses local demo data so judges can experience the UI immediately. The Spring Boot backend provides the production-oriented MongoDB REST structure. Replace the demo API calls with the backend URL when deploying the integrated version.
