# Weakness → Solution Engine

This is a core differentiator for the hackathon.

## 1. Missing technical depth

**Detection:** Answer mentions the concept but not the mechanism, trade-off, complexity or implementation details.

**Solution shown to student:**
- Review the underlying mechanism.
- Add one technical detail.
- Explain one trade-off.
- Retry the question.

## 2. No practical example

**Detection:** Student gives only a definition.

**Solution:**
- Add a short Java/Python/SQL example.
- Relate the concept to a project.
- Explain when it should be used.

## 3. Poor communication

**Detection:** Long, unstructured or repetitive answer.

**Solution:**
Use:
1. Definition
2. Explanation
3. Example
4. Conclusion

## 4. Incomplete answer

**Detection:** Important concepts expected for the role are missing.

**Solution:**
AI displays the missing points and creates a mini revision task.

## 5. Repeated weakness

**Detection:** Same weakness appears in multiple interviews.

**Solution:**
Move the weakness to the Skill Analysis page and recommend a 7-day practice plan.

## 6. Low progress

**Detection:** Score is not improving over recent interviews.

**Solution:**
Show targeted questions instead of repeating random questions.
