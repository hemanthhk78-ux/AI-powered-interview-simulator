# IntervueAI Architecture

## Frontend
React + Vite + responsive CSS.

## Backend
Java 17 + Spring Boot REST API.

## Database
MongoDB using Spring Data MongoDB.

## AI
AiEvaluationService provides a stable evaluation contract. The included demo provider allows a hackathon demo without an API key. A real Gemini/OpenAI adapter can be connected without changing the React result model.

## Request flow

React form
→ POST /api/interviews/{id}/evaluate
→ InterviewController
→ AiEvaluationService
→ Evaluation JSON
→ MongoDB Answer document
→ React Result page

## Security

Passwords are BCrypt-hashed. The project contains a JWT-ready security boundary. For production, add JwtAuthenticationFilter and issue short-lived access tokens with refresh-token rotation.
