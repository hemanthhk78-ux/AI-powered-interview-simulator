# 3-Minute Hackathon Demo

### 0:00 — Problem
"Students practice interviews, but most platforms only tell them a score. They don't tell them how to fix the weakness."

### 0:30 — Solution
"IntervueAI is an AI mock interview simulator that converts every answer into a score, strengths, weaknesses and a concrete improvement plan."

### 1:00 — Dashboard
Show overall score, interview count, streak, skill bars and AI opportunity.

### 1:30 — Interview
Start Java Developer → Technical → Intermediate → 10 questions.
Submit an answer.

### 2:00 — AI evaluation
Show score breakdown.
Highlight weaknesses.

### 2:20 — Differentiator
Open "Turn weaknesses into solutions".
Explain that every weakness becomes an actionable practice item.

### 2:40 — Analytics
Show score growth and skill gaps.
Explain that repeated weaknesses are tracked.

### 3:00 — Close
"IntervueAI doesn't just evaluate students. It creates a measurable path from weak answer to interview readiness."
